# KPIs Social Extractor v1.1

## Overview
KPIs Social Extractor is a powerful web application designed to automatically extract and analyze key performance indicators (KPIs) from various social media platforms. This tool helps marketers, social media managers, and business owners track their social media performance across multiple platforms in one centralized dashboard.

## Features

### Official API Integration
- Connects with official APIs from major social media platforms:
  - Facebook
  - Instagram
  - Twitter/X
  - LinkedIn
  - YouTube
  - TikTok
- Intelligent fallback to web scraping when API access is limited

### Comprehensive KPI Extraction
- Followers/Subscribers count
- Post/Content frequency
- Engagement metrics (likes, comments, shares)
- Platform-specific metrics (views, retweets, etc.)
- Calculated engagement rates

### Interactive Dashboard
- Visual representation of followers across platforms
- Engagement rate comparison
- Post frequency analysis
- Performance scoring system
- AI-powered recommendations

### User-Friendly Interface
- Simple form for entering social media URLs
- Clear visualization of extracted data
- Responsive design for desktop and mobile
- Intuitive navigation between extraction and analytics

## Technical Details
- Built with Flask (Python backend)
- Modern JavaScript frontend
- Chart.js for data visualization
- Bootstrap for responsive UI
- Session-based data storage for analytics

## Requirements
- Python 3.12 or higher
- Modern web browser
- Internet connection
- API keys (optional, for enhanced functionality)

## Getting Started
1. Install dependencies using `pip install -r requirements-py312.txt`
2. Run the application with `python main.py`
3. Access the web interface at http://localhost:5000
4. Enter your social media URLs and click "Extract KPIs"

For detailed installation instructions, please refer to the `installation-v1-1.txt` file.

## Version History
- v1.1: Added official API integration, real-time data processing, and enhanced dashboard
- v1.0: Initial release with basic scraping functionality

## License
This software is proprietary and confidential.

## Contact
For support or inquiries, please contact the development team.
